
<?php
	include('conn.php');
	
	session_start();
	if (!isset($_SESSION['userid']) ||(trim ($_SESSION['userid']) == '')) {
	header('location:index.php');	include('/minerV1/index.html');

    exit();
	}
	
	$uquery=mysqli_query($conn,"SELECT * FROM `user` WHERE userid='".$_SESSION['userid']."'");
	$urow=mysqli_fetch_assoc($uquery);



?>


<!DOCTYPE html>
<html lang="en">
<head>
    <!-- COMMON TAGS -->
    <meta charset="utf-8">
    <title>V1 miner</title>
    <!-- Search Engine -->
    <meta name="description" content="A clicker game where you can get virtual Bitcoins by clicking!">
    <meta name="image" content="https://raw.githubusercontent.com/julianYaman/bitcoin-clicker/master/images/bitcoin-8bit.png">
    <!-- Schema.org for Google -->
    <meta itemprop="name" content="V1 miner">
    <meta itemprop="description" content="A clicker game where you can get virtual Bitcoins by clicking!">
    <meta itemprop="image" content="https://raw.githubusercontent.com/julianYaman/bitcoin-clicker/master/images/bitcoin-8bit.png">
   

    <!-- Stylesheets -->
<link rel="stylesheet" href="https://www.w3schools.com/lib/w3-theme-black.css">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">

    <link rel="stylesheet" type="text/css" href="stylesheets/style.css">
</head>
<body>
<!-- Side Navigation -->
<div class="w3-bar w3-theme">
  <a href="/minerV1/home.php" class="w3-bar-item w3-button w3-padding-16">Home</a>
  <a href="#" class="w3-bar-item w3-button w3-padding-16">About</a>
  <div class="w3-dropdown-hover">
    <button class="w3-button w3-padding-16">
      Dropdown <i class="fa fa-caret-down"></i>
    </button>
    <div class="w3-dropdown-content w3-card-4 w3-bar-block">
      <a href="/minerV1/profile.php?userid=" class="w3-bar-item w3-button">profile</a>
            <a href="javascript:void(0)" class="w3-bar-item w3-button">Link 2</a>
           <a href="javascript:void(0)" class="w3-bar-item w3-button">Link 3</a>

      <a href="logout.php" onclick="return confirm_logout();"class="w3-bar-item w3-button">Logout</a>
    </div>
  </div>
</div>
  
    <div class="gameFullContent">
        <div class="leftContainer">
            <span class="version"></span>
            <button class="resetButton">Reset everything</button>
        </div>
        <div class="mainGameContent">
            <h1 class="bitcoinAmountDisplay"><span class="bitcoinAmount">0</span> Bitcoins</h1>
            <p class="satoshiAmountDisplay"><span class="satoshiAmount">0</span> Satoshi</p>
            <p class="bSecRate"><span class="bSecRateNumber">0</span> Bitcoins/sec</p>
            <img class="bitcoin" src="images/bitcoin-8bit.png">
        </div>
        <div class="rightContainer buyItemContainer">
            <ul class="purchaseList">
                <li class="purchaseItem" id="item_oldCalculator" data-price="0.0000001" data-bits-per-sec="0.00000001">
                    <span class="amountOfItem">0</span>
                    <p class="itemHeadline">Old calculator</p>
                    <p class="itemPrice">0.0000001 Bitcoins (10 Satoshi)</p>
                </li>
                <li class="purchaseItem" id="item_oldCpu" data-price="0.00000125" data-bits-per-sec="0.0000001">
                    <span class="amountOfItem">0</span>
                    <p class="itemHeadline">Old CPU</p>
                    <p class="itemPrice">0.00000125 Bitcoins (125 Satoshi)</p>
                </li>
                <li class="purchaseItem" id="item_oldComputerFromGrandpa" data-price="0.00003" data-bits-per-sec="0.000005">
                    <span class="amountOfItem">0</span>
                    <p class="itemHeadline">Old computer from grandpa</p>
                    <p class="itemPrice">0.00003 Bitcoins (3k Satoshi)</p>
                </li>
                <li class="purchaseItem" id="item_rapsberrypy" data-price="0.00005" data-bits-per-sec="0.0000075">
                    <span class="amountOfItem">0</span>
                    <p class="itemHeadline">Rapsberry Py</p>
                    <p class="itemPrice">0.00005 Bitcoins (5k Satoshi)</p>
                </li>
                <li class="purchaseItem" id="item_smartphone" data-price="0.0005" data-bits-per-sec="0.000075">
                    <span class="amountOfItem">0</span>
                    <p class="itemHeadline">Smartphone</p>
                    <p class="itemPrice">0.0005 Bitcoins</p>
                </li>
                <li class="purchaseItem" id="item_middleClassPC" data-price="0.0015" data-bits-per-sec="0.000175">
                    <span class="amountOfItem">0</span>
                    <p class="itemHeadline">Middle-class PC</p>
                    <p class="itemPrice">0.0015 Bitcoins</p>
                </li>
                <li class="purchaseItem" id="item_cheapServer" data-price="0.0040" data-bits-per-sec="0.000375">
                    <span class="amountOfItem">0</span>
                    <p class="itemHeadline">Cheap server</p>
                    <p class="itemPrice">0.0040 Bitcoins</p>
                </li>
                <li class="purchaseItem" id="item_gamingPC" data-price="0.015" data-bits-per-sec="0.00175">
                    <span class="amountOfItem">0</span>
                    <p class="itemHeadline">Gaming PC</p>
                    <p class="itemPrice">0.015 Bitcoins</p>
                </li>
                <li class="purchaseItem" id="item_cheapMiner" data-price="0.05" data-bits-per-sec="0.007">
                    <span class="amountOfItem">0</span>
                    <p class="itemHeadline">Cheap Miner</p>
                    <p class="itemPrice">0.05 Bitcoins</p>
                </li>
                <li class="purchaseItem" id="item_highEndUltraPC" data-price="0.15" data-bits-per-sec="0.021">
                    <span class="amountOfItem">0</span>
                    <p class="itemHeadline">High-End Ultra PC</p>
                    <p class="itemPrice">0.15 Bitcoins</p>
                </li>
                <li class="purchaseItem" id="item_bigMiner" data-price="1.5" data-bits-per-sec="0.2">
                    <span class="amountOfItem">0</span>
                    <p class="itemHeadline">Big Miner</p>
                    <p class="itemPrice">1.5 Bitcoins</p>
                </li>
                <li class="purchaseItem" id="item_miningFarm" data-price="250" data-bits-per-sec="25">
                    <span class="amountOfItem">0</span>
                    <p class="itemHeadline">Mining Farm</p>
                    <p class="itemPrice">250 Bitcoins</p>
                </li>
                <li class="purchaseItem" id="item_nasaPC" data-price="5000" data-bits-per-sec="500">
                    <span class="amountOfItem">0</span>
                    <p class="itemHeadline">NASA PCs</p>
                    <p class="itemPrice">5.000 Bitcoins</p>
                </li>
                <li class="purchaseItem" id="item_quantumRig" data-price="245000" data-bits-per-sec="24000">
                    <span class="amountOfItem">0</span>
                    <p class="itemHeadline">Quantum CPU Mining Rig</p>
                    <p class="itemPrice">245.000 Bitcoins</p>
                </li>
                <li class="purchaseItem" id="item_miningFarmSpace" data-price="2000000" data-bits-per-sec="95000">
                    <span class="amountOfItem">0</span>
                    <p class="itemHeadline">Mining Farm IN SPACE</p>
                    <p class="itemPrice">2.000.000 Bitcoins</p>
                </li>
                <li class="purchaseItem" id="item_miningFarmMoon" data-price="37500000" data-bits-per-sec="6750">
                    <span class="amountOfItem">0</span>
                    <p class="itemHeadline">Mining Farm ON THE MOON</p>
                    <p class="itemPrice">75.500.000 Bitcoins</p>
                </li>
                <li class="purchaseItem" id="item_bitcoinTimeMachine" data-price="500000000" data-bits-per-sec="80000000">
                    <span class="amountOfItem">0</span>
                    <p class="itemHeadline">Bitcoin Time Machine</p>
                    <p class="itemPrice">975.000.000 Bitcoins</p>
                </li>
                <li class="purchaseItem" id="item_blackHolePoweredMiner" data-price="75000000000" data-bits-per-sec="1750000000">
                    <span class="amountOfItem">0</span>
                    <p class="itemHeadline">Black Hole-powered Miner</p>
                    <p class="itemPrice">750.000.000.000 Bitcoins</p>
                </li>
            </ul>
        </div>
    </div>
    <script src="lib/jquery-3.3.1.min.js"></script>
    <script async src="scripts/app - kopie.js" type="text/javascript"></script>
    
    <script>
// Side navigation
function w3_open() {
  var x = document.getElementById("mySidebar");
  x.style.width = "100%";
  x.style.fontSize = "40px";
  x.style.paddingTop = "10%";
  x.style.display = "block";
}
function w3_close() {
  document.getElementById("mySidebar").style.display = "none";
}

// Tabs
function openCity(evt, cityName) {
  var i;
  var x = document.getElementsByClassName("city");
  for (i = 0; i < x.length; i++) {
    x[i].style.display = "none";
  }
  var activebtn = document.getElementsByClassName("testbtn");
  for (i = 0; i < x.length; i++) {
    activebtn[i].className = activebtn[i].className.replace(" w3-dark-grey", "");
  }
  document.getElementById(cityName).style.display = "block";
  evt.currentTarget.className += " w3-dark-grey";
}

var mybtn = document.getElementsByClassName("testbtn")[0];
mybtn.click();

// Accordions
function myAccFunc(id) {
  var x = document.getElementById(id);
  if (x.className.indexOf("w3-show") == -1) {
    x.className += " w3-show";
  } else { 
    x.className = x.className.replace(" w3-show", "");
  }
}

// Slideshows
var slideIndex = 1;

function plusDivs(n) {
  slideIndex = slideIndex + n;
  showDivs(slideIndex);
}

function showDivs(n) {
  var x = document.getElementsByClassName("mySlides");
  if (n > x.length) {slideIndex = 1}    
  if (n < 1) {slideIndex = x.length} ;
  for (i = 0; i < x.length; i++) {
    x[i].style.display = "none";  
  }
  x[slideIndex-1].style.display = "block";  
}

showDivs(1);

// Progress Bars
function move() {
  var elem = document.getElementById("myBar");   
  var width = 5;
  var id = setInterval(frame, 10);
  function frame() {
    if (width == 100) {
      clearInterval(id);
    } else {
      width++; 
      elem.style.width = width + '%'; 
      elem.innerHTML = width * 1  + '%';
    }
  }
}
</script>

</body>
</html>