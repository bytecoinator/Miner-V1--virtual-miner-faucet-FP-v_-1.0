<?php
$host="localhost"; 
$username="czecoymy_admin";
$password="GywC7w9iJcGjxT6";
$database="czecoymy_pad_to_raid";
$table="adv_tr_ptc";
$connection = mysql_connect("$host", "$username", "$password") or die ("Nemuzu se p�ipojit na server");
mysql_select_db("$database") or die ("�patn� datab�ze");
$sql = "TRUNCATE TABLE `$table`";
mysql_query($sql);
mysql_close($connection);
?>