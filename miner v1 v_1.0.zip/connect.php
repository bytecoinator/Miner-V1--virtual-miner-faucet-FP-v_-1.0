<?php
$db_server = 'locallhost'; /* Název serveru, ke kterému se budeme připojovat */
$db_login = 'czecoymy_admin'; /* Jméno uživatele do DB */
$db_password = 'GywC7w9iJcGjxT6'; /* Heslo uživatele do DB */
$db_name = 'czecoymy_pad_to_raid'; /* Název databáze, ve které jsme si vytvořili tabulku "uzivatele" */
$spojeni = @MySQL_Connect($db_server ,$db_login, $db_password);
@MySQL_Select_DB($db_name)or die('<p style="color: red">Nastala chyba v pripojeni k databazi');
mysql_query("set names utf8");
?>