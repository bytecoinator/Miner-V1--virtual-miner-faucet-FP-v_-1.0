<?php
date_default_timezone_set("Asia/Manila");
$date=date('F j, Y g:i:a');

//mysqli procedural
$conn=mysqli_connect("localhost","czecoymy_admin","GywC7w9iJcGjxT6","czecoymy_pad_to_raid");
if(!$conn){
	die("Connection failed: " . mysqli_connect_error());
}
?>