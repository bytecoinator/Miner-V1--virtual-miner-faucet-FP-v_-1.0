# Sources of the files used in the game:

### Bitcoin PNG
Source: [Here](https://pngimg.com/download/36992)