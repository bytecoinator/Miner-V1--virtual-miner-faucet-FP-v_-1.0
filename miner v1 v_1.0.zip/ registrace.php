<?php
include "connect.php";/* připojení k databázi - budeme se tomu věnovat níže... */
if(isset($_POST['submit'])) {
 $nick = mysql_real_escape_string($_POST['nick']);
 $heslo = mysql_real_escape_string($_POST['heslo']);
 $over_heslo = mysql_real_escape_string($_POST['over_heslo']);
 $md5_heslo = md5($heslo);
 $email = mysql_real_escape_string($_POST['email']);
 /* Nyní ověříme, zda byly zadané všechny potřebné údaje (registračnímu formuláři se budeme věnovat níže) */
 $user_check = mysql_query("SELECT login FROM uzivatele WHERE login='".$nick."'");
 if($nick==""){echo"Nebyl vyplněn nick!";}
 else if(mysql_num_rows($user_check)){echo"Tento nick používá již jiný uživatel.";}
 else if($heslo==""){echo"Nebylo vyplněno heslo";}
 else if($over_heslo==""){echo"Nebylo vyplněno ověřovací heslo";}
 else if($heslo!=$over_heslo){echo"Vyplněná hesla se neshodují";}
 else if($email==""){echo"Nebyl vyplněn email";}
 else{
 $sql= mysql_query("INSERT INTO uzivatele VALUES ('','$nick','$md5_heslo','$email')") or die(mysql_error());
 echo"Registrace byla úspěšně dokončena!";
 }
}
?><form action="#" method="post"> 
<table> 
<tr> <td>Přezdívka: </td> <td><input type="text" name="nick" value="<?php if(isset($_POST["nick"])){echo $_POST["nick"];}?>" size="25" tabindex="1" /></td> </tr>
<tr> <td>Heslo: </td> <td><input type="password" name="heslo" value="" size="25" tabindex="2" /></td> </tr> 
<tr> <td>Ověření hesla: </td> <td><input type="password" name="over_heslo" value="" size="25" tabindex="3" /></td> </tr> 
<tr> <td>Email: </td> <td><input type="text" name="email" value="<?php if(isset($_POST["email"])){echo $_POST["email"];}?>" size="25" tabindex="4" /></td> </tr> 
<tr> <td colspan="2"><input type="submit" name="submit" value="Registrovat se" /></td> </tr> 
</table> 
</form>